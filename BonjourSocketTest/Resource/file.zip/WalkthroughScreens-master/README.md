WalkthroughScreens
==================

Walkthrough Screens View Controller (like in Path)

![alt tag](http://habrastorage.org/storage3/546/bcd/1ec/546bcd1ec56916469df24444c7830a9a.jpg)
![alt tag](http://habrastorage.org/storage3/61a/4ee/682/61a4ee68287e63b42641cbe51adde30f.png)
