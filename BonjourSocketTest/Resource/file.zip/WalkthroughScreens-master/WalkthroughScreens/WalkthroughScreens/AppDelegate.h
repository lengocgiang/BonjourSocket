//
//  AppDelegate.h
//  WalkthroughScreens
//
//  Created by Anthony Marchenko on 1/21/14.
//  Copyright (c) 2014 Anthony Marchenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
